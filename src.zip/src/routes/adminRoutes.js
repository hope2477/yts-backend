const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const imageUploadMiddleware = require('../middleware/imageUploadMiddleware');

// Controllers
const adminVehicleController = require('../controllers/adminVehicleController');
const adminPropertyController = require('../controllers/adminPropertyController');
const adminInquiryController = require('../controllers/adminInquiryController');
const adminFeatureController = require('../controllers/adminFeatureController');
const adminDashboardController = require('../controllers/adminDashboardController');
const adminSystemController = require('../controllers/adminSystemController');
const adminHolidayHomeController = require('../controllers/adminHolidayHomeController')
const adminBlogController = require('../controllers/adminBlogController');

const router = express.Router();

// Apply authentication middleware to all admin routes
router.use(authMiddleware.verifyToken);

// Dashboard routes
router.get('/dashboard/overview',
  authMiddleware.requirePermission('system.view_dashboard'),
  adminDashboardController.getDashboardOverview
);
router.get('/dashboard/stats', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminDashboardController.getDashboardStats
);
router.get('/dashboard/recent-inquiries', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminDashboardController.getRecentInquiries
);
router.get('/dashboard/monthly-stats', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminDashboardController.getMonthlyStats
);
router.get('/dashboard/popular-vehicles', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminDashboardController.getPopularVehicles
);
router.get('/dashboard/popular-properties', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminDashboardController.getPopularProperties
);

// Vehicle management routes
router.get('/vehicles', 
  authMiddleware.requirePermission('vehicle.view'), 
  adminVehicleController.getAllVehicles
);
router.get('/vehicles/:id', 
  authMiddleware.requirePermission('vehicle.view'), 
  adminVehicleController.getVehicleById
);
router.post('/vehicles', 
  authMiddleware.requirePermission('vehicle.create'), 
  imageUploadMiddleware.validateImageUpload(),
  adminVehicleController.createVehicle
);
router.put('/vehicles/:id', 
  authMiddleware.requirePermission('vehicle.update'), 
  imageUploadMiddleware.validateImageUpload(),
  adminVehicleController.updateVehicle
);
router.delete('/vehicles/:id', 
  authMiddleware.requirePermission('vehicle.delete'), 
  adminVehicleController.deleteVehicle
);
router.put('/vehicles/:id/availability', 
  authMiddleware.requirePermission('vehicle.manage_availability'), 
  adminVehicleController.updateVehicleAvailability
);
router.get('/vehicle-features', 
  authMiddleware.requirePermission('vehicle.view'), 
  adminVehicleController.getVehicleFeatures
);
router.put('/vehicles/:id/featured-status', 
  authMiddleware.requirePermission('vehicle.update'), 
  adminVehicleController.updateFeaturedStatus
);

// Property management routes
router.get('/properties', 
  authMiddleware.requirePermission('property.view'), 
  adminPropertyController.getAllProperties
);
router.get('/properties/:id', 
  authMiddleware.requirePermission('property.view'), 
  adminPropertyController.getPropertyById
);
router.post('/properties', 
  authMiddleware.requirePermission('property.create'), 
  imageUploadMiddleware.validateImageUpload(),
  adminPropertyController.createProperty
);
router.put('/properties/:id', 
  authMiddleware.requirePermission('property.update'), 
  imageUploadMiddleware.validateImageUpload(),
  adminPropertyController.updateProperty
);
router.delete('/properties/:id', 
  authMiddleware.requirePermission('property.delete'), 
  adminPropertyController.deleteProperty
);
router.put('/properties/:id/availability', 
  authMiddleware.requirePermission('property.manage_availability'), 
  adminPropertyController.updatePropertyAvailability
);
router.get('/property-features', 
  authMiddleware.requirePermission('property.view'), 
  adminPropertyController.getPropertyFeatures
);
router.put('/properties/:id/featured-status', 
  authMiddleware.requirePermission('property.update'), 
  adminPropertyController.updatePropertyFeaturedStatus
);

// Inquiry management routes
router.get('/inquiries', 
  authMiddleware.requirePermission('inquiry.view'), 
  adminInquiryController.getAllInquiries
);
router.get('/inquiries/:id', 
  authMiddleware.requirePermission('inquiry.view'), 
  adminInquiryController.getInquiryById
);
router.put('/inquiries/:id/status', 
  authMiddleware.requirePermission('inquiry.update'), 
  adminInquiryController.updateInquiryStatus
);
router.delete('/inquiries/:id', 
  authMiddleware.requirePermission('inquiry.delete'), 
  adminInquiryController.deleteInquiry
);
router.get('/inquiry-stats', 
  authMiddleware.requirePermission('inquiry.view'), 
  adminInquiryController.getInquiryStats
);

// Feature management routes
router.get('/features', 
  authMiddleware.requirePermission('feature.view'), 
  adminFeatureController.getAllFeatures
);
router.get('/features/:id', 
  authMiddleware.requirePermission('feature.view'), 
  adminFeatureController.getFeatureById
);
router.post('/features', 
  authMiddleware.requirePermission('feature.create'), 
  adminFeatureController.createFeature
);
router.put('/features/:id', 
  authMiddleware.requirePermission('feature.update'), 
  adminFeatureController.updateFeature
);
router.delete('/features/:id', 
  authMiddleware.requirePermission('feature.delete'), 
  adminFeatureController.deleteFeature
);

// System management routes
router.post('/system/cleanup-images', 
  authMiddleware.requirePermission('system.manage_settings'), 
  adminSystemController.cleanupImages
);
router.get('/system/storage-stats', 
  authMiddleware.requirePermission('system.view_dashboard'), 
  adminSystemController.getStorageStats
);

// Holiday Home availability routes
router.get('/holidayHome/:id/availability', 
  authMiddleware.requirePermission('property.view'), 
  adminHolidayHomeController.getHolidayHomeAvailabilityByID
);
router.put('/holidayHome/:id/availability', 
  authMiddleware.requirePermission('property.view'), 
  adminHolidayHomeController.updateHolidayHomeAvailability
);

// Blog management routes
router.get('/blogs',
  authMiddleware.requirePermission('blog.view'),
  adminBlogController.getAllBlogs.bind(adminBlogController)
);
router.get('/blogs/:id',
  authMiddleware.requirePermission('blog.view'),
  adminBlogController.getBlogById.bind(adminBlogController)
);
router.post('/blogs',
  authMiddleware.requirePermission('blog.create'),
  imageUploadMiddleware.validateImageUpload(),
  adminBlogController.createBlog.bind(adminBlogController)
);
router.put('/blogs/:id',
  authMiddleware.requirePermission('blog.update'),
  imageUploadMiddleware.validateImageUpload(),
  adminBlogController.updateBlog.bind(adminBlogController)
);
router.delete('/blogs/:id',
  authMiddleware.requirePermission('blog.delete'),
  adminBlogController.deleteBlog.bind(adminBlogController)
);

module.exports = router;