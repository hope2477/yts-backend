const fs = require('fs');
const path = require('path');
require('dotenv').config()

class ImageUploadHelper {
  constructor() {
    this.uploadDir = path.join(process.cwd(), 'public/uploads/rentalImages');
    this.ensureUploadDirectory();

    // Read frontend base URL from .env
    this.frontendUrl = process.env.FRONTEND_URL_IMAGES || '';
  }

  ensureUploadDirectory() {
    if (!fs.existsSync(this.uploadDir)) {
      fs.mkdirSync(this.uploadDir, { recursive: true });
      console.log('Created upload directory:', this.uploadDir);
    }
  }

  /**
   * Save base64 image to file system with specific naming convention
   * @param {string} base64Data - Base64 encoded image data
   * @param {string} filename - Specific filename to use
   * @returns {Promise<string>} - Returns the filename only
   */
  async saveBase64Image(base64Data, filename) {
    try {
      // Remove data URL prefix if present (data:image/jpeg;base64,)
      const base64String = base64Data.replace(/^data:image\/[a-z]+;base64,/, '');
      
      // Get extension from base64 data
      const extension = this.getImageExtension(base64Data);
      const fullFilename = `${filename}.${extension}`;
      
      const filePath = path.join(this.uploadDir, fullFilename);
      
      // Convert base64 to buffer and save
      const imageBuffer = Buffer.from(base64String, 'base64');
      fs.writeFileSync(filePath, imageBuffer);
      
      // Return only the filename (not the full path)
      return fullFilename;
      
    } catch (error) {
      console.error('Error saving base64 image:', error);
      throw new Error('Failed to save image');
    }
  }

  /**
   * Build SEO-friendly image filename stem (no extension).
   * e.g. toyota-avanza-2016-car-rental-colombo-1
   */
  buildSeoFilenameStem(parts, index = 1) {
    const raw = Array.isArray(parts) ? parts.join(' ') : String(parts || '');
    const slug = raw
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 120);
    const base = slug || 'listing';
    return `${base}-${index}`;
  }

  /**
   * Save multiple base64 images with SEO-friendly naming
   * @param {Array} base64Images - Array of base64 image strings
   * @param {string} identifier - Legacy plate/name OR pre-built SEO stem (without -N suffix)
   * @param {string} type - 'vehicle' or 'property'
   * @returns {Promise<Array>} - Returns array of filenames only
   */
  async saveMultipleBase64Images(base64Images, identifier, type) {
    if (!Array.isArray(base64Images) || base64Images.length === 0) {
      return [];
    }

    const typeSuffix =
      type === 'property' ? 'apartment-rent-colombo' : 'car-rental-colombo';
    const stemBase = this.buildSeoFilenameStem(`${identifier} ${typeSuffix}`, 0).replace(/-0$/, '');

    const savedImages = [];

    for (let i = 0; i < base64Images.length; i++) {
      const filename = `${stemBase}-${i + 1}`;
      const savedFilename = await this.saveBase64Image(base64Images[i], filename);
      savedImages.push(savedFilename);
    }

    return savedImages;
  }

  /**
   * Get image extension from base64 data
   * @param {string} base64Data - Base64 encoded image
   * @returns {string} - File extension
   */
  getImageExtension(base64Data) {
    if (base64Data.includes('data:image/jpeg') || base64Data.includes('data:image/jpg')) {
      return 'jpg';
    } else if (base64Data.includes('data:image/png')) {
      return 'png';
    } else if (base64Data.includes('data:image/gif')) {
      return 'gif';
    } else if (base64Data.includes('data:image/webp')) {
      return 'webp';
    }
    return 'jpg'; // Default fallback
  }

  /**
   * Delete image file from filesystem using filename
   * @param {string} filename - Image filename to delete
   * @returns {boolean} - Success status
   */
  deleteImage(filename) {
    try {
      if (!filename) {
        return false;
      }
      
      const filePath = path.join(this.uploadDir, filename);
      
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        console.log('Deleted image:', filename);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error deleting image:', error);
      return false;
    }
  }

  /**
   * Delete multiple images
   * @param {Array} filenames - Array of image filenames to delete
   * @returns {number} - Number of successfully deleted images
   */
  deleteMultipleImages(filenames) {
    if (!Array.isArray(filenames)) return 0;
    
    let deletedCount = 0;
    filenames.forEach(filename => {
      if (this.deleteImage(filename)) {
        deletedCount++;
      }
    });
    
    return deletedCount;
  }

  /**
   * Process images for vehicle/property creation
   * @param {Array} base64Images - Array of base64 images from frontend
   * @param {string} type - 'vehicle' or 'property'
   * @param {string} identifier - Vehicle plate number or property name for filename
   * @returns {Promise<Object>} - Returns {mainImage, allImages}
   */
  async processImagesForCreation(base64Images, type, identifier) {
    if (!base64Images || !Array.isArray(base64Images) || base64Images.length === 0) {
      return { mainImage: '', allImages: [] };
    }

    const savedImages = await this.saveMultipleBase64Images(base64Images, identifier, type);
    
    return {
      mainImage: savedImages[0] || '',
      allImages: savedImages // All images including the first one
    };
  }

  /**
   * Process images for vehicle/property updates
   * This handles mixed arrays of existing URLs/filenames and new base64 images.
   * Order of `imageData` is preserved: index 0 remains the main/thumbnail image.
   * @param {Array} imageData - Mixed array of existing filenames and new base64 images
   * @param {Array} existingImages - Current image filenames in database
   * @param {string} type - 'vehicle' or 'property'
   * @param {string} identifier - Vehicle plate number or property name
   * @returns {Promise<Object>} - Returns {mainImage, allImages, deletedImages}
   */
  async processImagesForUpdate(imageData, existingImages, type, identifier) {
    const result = {
      mainImage: '',
      allImages: [],
      deletedImages: []
    };

    const normalizedExisting = (existingImages || [])
      .map((img) => this.getFilenameFromUrl(img))
      .filter(Boolean);

    if (!imageData || !Array.isArray(imageData) || imageData.length === 0) {
      result.mainImage = normalizedExisting[0] || '';
      result.allImages = [...normalizedExisting];
      return result;
    }

    // Find max numeric suffix so new files don't collide
    let maxSuffix = 0;
    normalizedExisting.forEach((img) => {
      const match = img.match(/-(\d+)\./);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxSuffix) maxSuffix = num;
      }
    });

    const typeSuffix =
      type === 'property' ? 'apartment-rent-colombo' : 'car-rental-colombo';
    const stemBase = this.buildSeoFilenameStem(`${identifier} ${typeSuffix}`, 0).replace(/-0$/, '');

    // Preserve caller order (thumbnail / images[0] must stay first)
    const ordered = [];
    const seen = new Set();
    let nextSuffix = maxSuffix + 1;

    for (const item of imageData) {
      if (typeof item !== 'string' || !item.trim()) continue;

      let filename = '';
      if (item.startsWith('data:image/')) {
        filename = await this.saveBase64Image(item, `${stemBase}-${nextSuffix++}`);
      } else {
        filename = this.getFilenameFromUrl(item);
      }

      if (!filename || seen.has(filename)) continue;
      seen.add(filename);
      ordered.push(filename);
    }

    const imagesToDelete = normalizedExisting.filter((img) => !seen.has(img));
    if (imagesToDelete.length > 0) {
      const deletedCount = this.deleteMultipleImages(imagesToDelete);
      result.deletedImages = imagesToDelete;
      console.log(`Deleted ${deletedCount} images during update`);
    }

    result.mainImage = ordered[0] || '';
    result.allImages = ordered;

    return result;
  }


  /**
   * Convert filename to full URL for frontend
   * @param {string} filename - Image filename
   * @returns {string} - Full URL
   */
  getImageUrl(filename) {
    if (!filename) return '';
    return `${this.frontendUrl}/uploads/rentalImages/${filename}`;
  }

  /**
   * Convert array of filenames to full URLs for frontend
   * @param {Array} filenames - Array of image filenames
   * @returns {Array} - Array of full URLs
   */
  getImageUrls(filenames) {
    if (!Array.isArray(filenames)) return [];
    return filenames
      .filter((filename) => typeof filename === 'string' && filename.trim())
      .map((filename) => `${this.frontendUrl}/uploads/rentalImages/${filename.trim()}`);
  }

  /**
   * Extract filename from URL
   * @param {string} url - Image URL
   * @returns {string} - Filename only
   */
  getFilenameFromUrl(url) {
    if (!url) return '';
    return path.basename(url);
  }

  /**
   * Extract filenames from URLs
   * @param {Array} urls - Array of image URLs
   * @returns {Array} - Array of filenames
   */
  getFilenamesFromUrls(urls) {
    if (!Array.isArray(urls)) return [];
    return urls.map(url => this.getFilenameFromUrl(url));
  }
}

module.exports = new ImageUploadHelper();